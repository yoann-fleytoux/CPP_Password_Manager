#ifndef COMPOSANTDOCUMENTATION_H
#define COMPOSANTDOCUMENTATION_H

class ComposantDocumentation
{
public:
    ComposantDocumentation();

    static void aide();
};

#endif // COMPOSANTDOCUMENTATION_H
